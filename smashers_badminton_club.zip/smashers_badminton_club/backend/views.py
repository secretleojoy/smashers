from flask import render_template, request, redirect, url_for, flash
from models import db, User, Event
from app import app

@app.route('/')
def home():
    events = Event.query.all()
    return render_template('index.html', events=events)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/events')
def events():
    events = Event.query.all()
    return render_template('events.html', events=events)

@app.route('/news')
def news():
    # For simplicity, adding static news. In a real app, you might query a database or an API.
    news_articles = [
        {
            "title": "Badminton Championship 2024",
            "date": "June 15, 2024",
            "content": "Smashers Badminton Club is proud to host the 2024 Badminton Championship in Bahrain."
        },
        {
            "title": "New Training Sessions Announced",
            "date": "May 10, 2024",
            "content": "Join our new training sessions to improve your badminton skills. Register now!"
        }
    ]
    return render_template('news.html', news_articles=news_articles)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            flash('Username already exists. Please choose a different one.', 'danger')
        else:
            new_user = User(username=username, password=password)
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('home'))
    return render_template('register.html')
