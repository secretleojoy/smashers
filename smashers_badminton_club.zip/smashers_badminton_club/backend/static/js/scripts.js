$(document).ready(function() {
    $('.fade-in').each(function(i) {
        $(this).delay((i + 1) * 500).queue(function(next) {
            $(this).addClass('visible');
            next();
        });
    });
});
