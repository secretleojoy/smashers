from flask import Flask, render_template, request, redirect, url_for
from models import db, User, Event
from config import Config
import os

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/events')
def events():
    events = Event.query.all()
    return render_template('events.html', events=events)

@app.route('/news')
def news():
    return render_template('news.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('home'))
    return render_template('register.html')

if __name__ == "__main__":
    if not os.path.exists('../database/site.db'):
        with app.app_context():
            db.create_all()
    app.run(debug=True)

from flask import Flask
from models import db
from config import Config
import os

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

# Import views to register routes
import views

if __name__ == "__main__":
    if not os.path.exists('../database/site.db'):
        with app.app_context():
            db.create_all()
    app.run(debug=True)

from __init__ import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)
